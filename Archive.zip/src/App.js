import './App.css';
import Axios from './components/Axios';


function App() {
  return (
    <div className="App">
      <Axios></Axios>
    </div>
  );
}

export default App;
